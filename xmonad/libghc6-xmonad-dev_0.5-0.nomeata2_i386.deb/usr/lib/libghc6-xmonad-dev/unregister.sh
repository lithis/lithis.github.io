#!/bin/sh

/usr/bin/ghc-pkg6 unregister xmonad-0.5
