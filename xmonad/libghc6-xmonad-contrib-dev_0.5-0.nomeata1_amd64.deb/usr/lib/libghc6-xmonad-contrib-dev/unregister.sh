#!/bin/sh

/usr/bin/ghc-pkg6 unregister xmonad-contrib-0.5
