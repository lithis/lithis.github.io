#!/bin/sh

echo 'name: xmonad-contrib
version: 0.5
license: BSD3
copyright:
maintainer: sjanssen@cse.unl.edu
stability:
homepage: http://xmonad.org/
package-url:
description: Third party tiling algorithms, configurations and scripts to xmonad,
             a tiling window manager for X.
             .
             For an introduction to building, configuring and using xmonad
             extensions, see "XMonad.Doc". In particular:
             .
             "XMonad.Doc.Configuring", a guide to configuring xmonad
             .
             "XMonad.Doc.Extending", using the contributed extensions library
             .
             "XMonad.Doc.Developing", introduction to xmonad internals and writing
             your own extensions.
category: System
author: Spencer Janssen
exposed: True
exposed-modules: XMonad.Doc XMonad.Doc.Configuring
                 XMonad.Doc.Extending XMonad.Doc.Developing XMonad.Actions.Commands
                 XMonad.Actions.ConstrainedResize XMonad.Actions.CopyWindow
                 XMonad.Actions.CycleWS XMonad.Actions.DeManage
                 XMonad.Actions.DwmPromote XMonad.Actions.DynamicWorkspaces
                 XMonad.Actions.FindEmptyWorkspace XMonad.Actions.FlexibleManipulate
                 XMonad.Actions.FlexibleResize XMonad.Actions.FloatKeys
                 XMonad.Actions.FocusNth XMonad.Actions.MouseGestures
                 XMonad.Actions.RotSlaves XMonad.Actions.RotView
                 XMonad.Actions.SimpleDate XMonad.Actions.SinkAll
                 XMonad.Actions.Submap XMonad.Actions.SwapWorkspaces
                 XMonad.Actions.TagWindows XMonad.Actions.Warp
                 XMonad.Actions.WindowBringer XMonad.Actions.WmiiActions
                 XMonad.Config.Sjanssen XMonad.Config.Dons XMonad.Config.Arossato
                 XMonad.Config.Droundy XMonad.Hooks.DynamicLog
                 XMonad.Hooks.EwmhDesktops XMonad.Hooks.ManageDocks
                 XMonad.Hooks.SetWMName XMonad.Hooks.UrgencyHook
                 XMonad.Hooks.XPropManage XMonad.Layout.Accordion
                 XMonad.Layout.Circle XMonad.Layout.Combo XMonad.Layout.Dishes
                 XMonad.Layout.DragPane XMonad.Layout.Grid XMonad.Layout.HintedTile
                 XMonad.Layout.LayoutCombinators XMonad.Layout.LayoutHints
                 XMonad.Layout.LayoutModifier XMonad.Layout.LayoutScreens
                 XMonad.Layout.MagicFocus XMonad.Layout.Magnifier
                 XMonad.Layout.Maximize XMonad.Layout.Mosaic XMonad.Layout.MosaicAlt
                 XMonad.Layout.MultiToggle XMonad.Layout.Named
                 XMonad.Layout.NoBorders XMonad.Layout.PerWorkspace
                 XMonad.Layout.ResizableTile XMonad.Layout.Roledex
                 XMonad.Layout.Spiral XMonad.Layout.Square XMonad.Layout.Tabbed
                 XMonad.Layout.ThreeColumns XMonad.Layout.ToggleLayouts
                 XMonad.Layout.TwoPane XMonad.Layout.WindowNavigation
                 XMonad.Layout.WorkspaceDir XMonad.Prompt.Directory XMonad.Prompt
                 XMonad.Prompt.Layout XMonad.Prompt.Man XMonad.Prompt.Shell
                 XMonad.Prompt.Ssh XMonad.Prompt.Window XMonad.Prompt.Workspace
                 XMonad.Prompt.XMonad XMonad.Prompt.AppendFile XMonad.Prompt.Input
                 XMonad.Prompt.Email XMonad.Util.Anneal XMonad.Util.CustomKeys
                 XMonad.Util.Dmenu XMonad.Util.Dzen XMonad.Util.EZConfig
                 XMonad.Util.Font XMonad.Util.Invisible XMonad.Util.NamedWindows
                 XMonad.Util.Run XMonad.Util.XSelection XMonad.Util.XUtils
hidden-modules:
import-dirs: /usr/lib/xmonad-contrib-0.5/ghc-6.6.1
library-dirs: /usr/lib/xmonad-contrib-0.5/ghc-6.6.1
hs-libraries: HSxmonad-contrib-0.5
extra-libraries:
extra-ghci-libraries:
include-dirs: /usr/lib/xmonad-contrib-0.5/ghc-6.6.1/include
includes:
depends: base-2.1.1 mtl-1.0.1 unix-2.1 X11-1.4.1 xmonad-0.5
hugs-options:
cc-options:
ld-options:
framework-dirs:
frameworks:
haddock-interfaces: /usr/share/doc/ghc6-doc/html/cabal_libraries/xmonad-contrib/doc/html/xmonad-contrib.haddock
haddock-html: /usr/share/doc/ghc6-doc/html/cabal_libraries/xmonad-contrib/doc/html' | /usr/bin/ghc-pkg6 update -
