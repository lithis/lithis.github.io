#!/bin/sh

/usr/bin/ghc-pkg6 unregister X11-1.4.1
