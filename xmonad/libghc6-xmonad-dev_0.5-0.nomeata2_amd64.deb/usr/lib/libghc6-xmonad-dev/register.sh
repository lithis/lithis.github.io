#!/bin/sh

echo 'name: xmonad
version: 0.5
license: BSD3
copyright:
maintainer: xmonad@haskell.org
stability:
homepage: http://xmonad.org
package-url:
description: xmonad is a tiling window manager for X. Windows are arranged
             automatically to tile the screen without gaps or overlap, maximising
             screen use. All features of the window manager are accessible from
             the keyboard: a mouse is strictly optional. xmonad is written and
             extensible in Haskell. Custom layout algorithms, and other
             extensions, may be written by the user in config files. Layouts are
             applied dynamically, and different layouts may be used on each
             workspace. Xinerama is fully supported, allowing windows to be tiled
             on several screens.
category: System
author: Spencer Janssen
exposed: True
exposed-modules: XMonad XMonad.Main XMonad.Core XMonad.Config
                 XMonad.Layout XMonad.ManageHook XMonad.Operations XMonad.StackSet
hidden-modules:
import-dirs: /usr/lib/xmonad-0.5/ghc-6.6.1
library-dirs: /usr/lib/xmonad-0.5/ghc-6.6.1
hs-libraries: HSxmonad-0.5
extra-libraries:
extra-ghci-libraries:
include-dirs: /usr/lib/xmonad-0.5/ghc-6.6.1/include
includes:
depends: base-2.1.1 X11-1.4.1 mtl-1.0.1 unix-2.1
hugs-options:
cc-options:
ld-options:
framework-dirs:
frameworks:
haddock-interfaces: /usr/share/doc/ghc6-doc/html/cabal_libraries/xmonad/doc/html/xmonad.haddock
haddock-html: /usr/share/doc/ghc6-doc/html/cabal_libraries/xmonad/doc/html' | /usr/bin/ghc-pkg6 update -
